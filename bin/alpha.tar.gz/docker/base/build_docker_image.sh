#!/usr/bin/env bash

# 构建镜像:
docker build -t cmswing_base:0.4 .





