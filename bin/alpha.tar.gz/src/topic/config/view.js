'use strict';
/**
 * template config
 */
export default {
    file_depr: '/'
};
