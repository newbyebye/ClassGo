/**
 * Created by Arterli on 2016/1/24.
 * 独立模型路由自定义；
 */
export default [
    [/^mod\/question\/(\d+).*$/,"mod/question/index/detail?id=:1"],
];