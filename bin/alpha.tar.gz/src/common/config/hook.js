'use strict';

/**
 * hook config
 * https://thinkjs.org/doc/middleware.html#toc-df6
 */
export default {
    //view_filter : ['append', 'debug_toolbar'],
    payload_parse: ['prepend', 'parse_wechat'],
    // logic_before: ["prepend", "csrf"]
}