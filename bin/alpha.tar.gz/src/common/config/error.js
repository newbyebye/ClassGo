'use strict';
/**
 * err config
 */
export default {
  //key: value
  key: "errno", //error number
  msg: "errmsg" //error message
};