'use strict';

export default {
    "meta_title_admin":"HOME",//后台管理首页标题
};