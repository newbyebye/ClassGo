/**
 * Created by arter on 2016/1/14.
 */
export default {
    cookie_name: "cmswing_locale", //存放语言的 cookie 名称
    default: "zh-CN" //默认语言
};